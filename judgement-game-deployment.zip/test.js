console.log('Testing Node.js execution');
console.log('Node version:', process.version);
